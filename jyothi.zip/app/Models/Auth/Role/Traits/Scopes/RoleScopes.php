<?php

namespace App\Models\Auth\Role\Traits\Scopes;

trait RoleScopes
{

}
