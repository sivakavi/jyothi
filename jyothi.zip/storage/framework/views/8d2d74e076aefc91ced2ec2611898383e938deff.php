
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>SubCategories File  / Create </h1>
    </div>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-6 center-margin">

            <form action="<?php echo e(route('admin.sub_categories_file.store')); ?>" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="sub_category_id" value="<?php echo e($_GET['sub_category_id']); ?>">

                <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                    <label for="name-field">Name</label>
                    <input type="text" id="name-field" name="name" class="form-control" value="<?php echo e(old("name")); ?>"/>
                    <?php if($errors->has("name")): ?>
                        <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group <?php if($errors->has('file')): ?> has-error <?php endif; ?>">
                    <label class="control-label col-sm-3" for="file">File:</label>
                    <input type="file" class="form-control" name="file" id="file" required>
                    <?php if($errors->has("file")): ?>
                        <span class="help-block"><?php echo e($errors->first("file")); ?></span>
                    <?php endif; ?>
                </div>
                <div class="well well-sm">
                    <button type="submit" class="btn btn-primary">Create</button>
                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.sub_categories.index')); ?>"><i class="glyphicon glyphicon-backward"></i> Back</a>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>