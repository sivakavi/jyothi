
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>SubCategories / Create </h1>
    </div>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-6 center-margin">

            <form action="<?php echo e(route('admin.sub_categories.store')); ?>" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                    <label for="name-field">Name</label>
                    <input type="text" id="name-field" name="name" class="form-control" value="<?php echo e(old("name")); ?>"/>
                    <?php if($errors->has("name")): ?>
                        <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group <?php if($errors->has('category_id')): ?> has-error <?php endif; ?>">
                    <label for="category_id-field">Category_id</label>
                    <select class="form-control" name="category_id">
                        <option value="">Select any one Category...</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has("category_id")): ?>
                    <span class="help-block"><?php echo e($errors->first("category_id")); ?></span>
                    <?php endif; ?>
                </div>
                <div class="well well-sm">
                    <button type="submit" class="btn btn-primary">Create</button>
                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.sub_categories.index')); ?>"><i class="glyphicon glyphicon-backward"></i> Back</a>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>