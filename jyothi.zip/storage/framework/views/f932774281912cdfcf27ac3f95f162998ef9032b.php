
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Assigns</h1>
    </div>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

            <form name="assign-list" action="<?php echo e(route('admin.assigns.store')); ?>" method="POST">
                <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                <div class="form-group">
                    <label for="college_id">College</label>
                    <select id = 
                    "college_id" class="form-control" name="college_id" required>
                        <option value="">Select any one College...</option>
                        <?php $__currentLoopData = $colleges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $college): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($college->id); ?>"><?php echo e($college->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="group_id">Group</label>
                    <select id = "group_id" class="form-control" name="group_id" required>
                        <option value="">Select any one Group...</option>
                    </select>
                </div>
                <br/>
                <br/>
                <br/>
                <br/>
                <div class="form-group">
                    <div class="row">
                    <div class="col-md-1"></div>
                    <div class="col-md-4">
                    <label>Selected List</label>
                    <ul id="assignCategories" class="sortClass"></ul>
                    </div>
                    <div class="col-md-2"></div>
                    <div class="col-md-4">
                    <label>Sub-Category List</label>
                        <ul id="subCategories" class="sortClass">
                            <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li id="<?php echo e($subCategory->id); ?>"><?php echo e($subCategory->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="col-md-1"></div>
                    </div>  
                </div>
                <br/>
                <br/>
                
                <center><button type="submit" id="update" class="btn btn-success" style="width:200px;">Update</button></center>
            
            </form>

            <br/>
                <br/>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
    <script>
        $(function() {
            $("#subCategories").sortable({
                connectWith: "#assignCategories",

                helper: function (e, li) {
                    this.copyHelper = li.clone().insertAfter(li);

                    $(this).data('copied', false);

                    return li.clone();
                },
                stop: function () {

                    var copied = $(this).data('copied');

                    if (!copied) {
                        this.copyHelper.remove();
                    }

                    this.copyHelper = null;
                },
                
                receive: function(e, ui){
                    $(ui.item[0]).remove();
                }
            });

            $("#assignCategories").sortable({
                connectWith: "#subCategories",
                receive: function (e, ui) {
                    ui.sender.data('copied', true);
                }
            });
                    
            $("#assignCategories").on("click", "li", function () {
                
            
            });   
        });
    </script>
    <script>
        $( document ).ready(function() {
            $( "#college_id" ).change(function() {
                var ajaxUrl = "<?php echo e(route('admin.assigns.getGroup')); ?>";
                var $select = $('#group_id');
                $select.find('option').remove();
                if($(this).val()!=""){
                    $.ajax({
                        url: ajaxUrl,
                        type: 'GET',
                        data: {
                            college_id: $(this).val()
                        },
                        success:function(response) {
                            var $select = $('#group_id');
                            $select.find('option').remove();
                            $select.append('<option value=' + '' + '>' + 'Select any one Group...' + '</option>');
                            $.each(response,function(key, value) 
                            {
                                $select.append('<option value=' + key + '>' + value + '</option>');
                            });
                        }
                    });
                }
            });
            $( "#group_id" ).change(function() {
                var ajaxUrl = "<?php echo e(route('admin.assigns.getGroupSubCategoryList')); ?>";
                var $ul = $('#assignCategories');
                $ul.find('li').remove();
                if($(this).val()!=""){
                    $.ajax({
                        url: ajaxUrl,
                        type: 'GET',
                        data: {
                            group_id: $(this).val()
                        },
                        success:function(response) {
                            var $ul = $('#assignCategories');
                            $ul.find('li').remove();
                            $.each(response,function(key, value) 
                            {
                                $ul.append($("<li id="+key+">").text(value));
                            });
                        }
                    });
                }
            });
            $( "#update" ).click(function(e) {
                e.preventDefault();
                var assignSubCategories = [];
                $('ul#assignCategories li').each(function () {
                    assignSubCategories.push($(this).attr("id"));
                });
                if(assignSubCategories.length === 0 || $('#group_id').val() == ""){
                    alert("Please fill all fields");
                }
                else{
                    var ajaxUrl = "<?php echo e(route('admin.assigns.store')); ?>";
                    $.ajax({
                        url: ajaxUrl,
                        type: 'POST',
                        data: {
                            "_token": $('#token').val(),
                            group_id: $('#group_id').val(),
                            assignSubCategories: $.unique(assignSubCategories)
                        },
                        success:function(response) {
                            location.reload();
                        }
                    })
                }
            });
            
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>