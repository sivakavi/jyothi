

<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header clearfix"></div>
    <div class="margin-top-50">
        <table class="table table-bordered">
            <tbody>
                <tr>
                <th scope="row">Name</th>
                <td><?php echo e($user->name); ?></td>
                </tr>
                <tr>
                <th scope="row">College Name</th>
                <td><?php echo e($user->college->name); ?></td>
                </tr>
                <tr>
                <th scope="row">User Email</th>
                <td><?php echo e($user->email); ?></td>
                </tr>
                <tr>
                <th scope="row">College Address</th>
                <td><?php echo e($user->college->address); ?></td>
                </tr>
                
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.student', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>