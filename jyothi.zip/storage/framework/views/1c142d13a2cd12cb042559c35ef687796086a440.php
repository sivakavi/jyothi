<?php $__env->startSection('title', __('views.admin.college.edit.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header clearfix">
        
    </div>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row margin-top-30">
        <div class="col-md-8 center-margin">
           <form action="<?php echo e(route('admin.colleges.update', $college->id)); ?>" method="POST">
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>College Update Form</h2>
                                    <ul class="nav navbar-right">
                                    <li class="cursor-pointer"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content margin-top-40">
                                    <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                                        <label for="name-field">Name</label>
                                        <input type="text" id="name-field" name="name" class="form-control" value="<?php echo e(is_null(old("name")) ? $college->name : old("name")); ?>"/>
                                        <?php if($errors->has("name")): ?>
                                            <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php if($errors->has('address')): ?> has-error <?php endif; ?>">
                                        <label for="address-field">Address</label>
                                        <textarea class="form-control" id="address-field" rows="3" name="address"><?php echo e(is_null(old("address")) ? $college->address : old("address")); ?></textarea>
                                        <?php if($errors->has("address")): ?>
                                            <span class="help-block"><?php echo e($errors->first("address")); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php if($errors->has('phno')): ?> has-error <?php endif; ?>">
                                        <label for="phno-field">Phno</label>
                                        <input type="text" id="phno-field" name="phno" class="form-control" value="<?php echo e(is_null(old("phno")) ? $college->phno : old("phno")); ?>"/>
                                        <?php if($errors->has("phno")): ?>
                                            <span class="help-block"><?php echo e($errors->first("phno")); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php if($errors->has('contact_person')): ?> has-error <?php endif; ?>">
                                        <label for="contact_person-field">Contact_person</label>
                                        <input type="text" id="contact_person-field" name="contact_person" class="form-control" value="<?php echo e(is_null(old("contact_person")) ? $college->contact_person : old("contact_person")); ?>"/>
                                        <?php if($errors->has("contact_person")): ?>
                                            <span class="help-block"><?php echo e($errors->first("contact_person")); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php if($errors->has('contact_person_phno')): ?> has-error <?php endif; ?>">
                                        <label for="contact_person_phno-field">Contact_person_phno</label>
                                        <input type="text" id="contact_person_phno-field" name="contact_person_phno" class="form-control" value="<?php echo e(is_null(old("contact_person_phno")) ? $college->contact_person_phno : old("contact_person_phno")); ?>"/>
                                        <?php if($errors->has("contact_person_phno")): ?>
                                            <span class="help-block"><?php echo e($errors->first("contact_person_phno")); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php if($errors->has('website')): ?> has-error <?php endif; ?>">
                                        <label for="website-field">Website</label>
                                        <input type="text" id="website-field" name="website" class="form-control" value="<?php echo e(is_null(old("website")) ? $college->website : old("website")); ?>"/>
                                        <?php if($errors->has("website")): ?>
                                            <span class="help-block"><?php echo e($errors->first("website")); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="well well-sm margin-top-50">
                                        <button type="submit" class="btn btn-primary btn-round btn-sm">Update College</button>
                                        <a class="btn btn-link pull-right" href="<?php echo e(route('admin.colleges.index')); ?>"><i class="glyphicon glyphicon-backward"></i>  Back</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    
            </form>
        </div>
    </div>

   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>