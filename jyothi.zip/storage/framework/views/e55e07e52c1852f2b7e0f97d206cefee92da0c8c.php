
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Questions / Lists 
        <a class="btn btn-success pull-right" href="<?php echo e(route('admin.questions.create')); ?>"><i class="glyphicon glyphicon-plus"></i> Create</a></h1>
    </div>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-6 center-margin">

            <form name="question-list">
                
                <div class="form-group">
                    <label for="category_id">Category</label>
                    <select id = 
                    "category_id" class="form-control" name="category_id" required>
                        <option value="">Select any one Category...</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="sub_category_id">Sub_Category</label>
                    <select id = "sub_category_id" class="form-control" name="sub_category_id" required>
                        <option value="">Select any one Sub Category...</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="test_id">Test</label>
                    <select id = 
                    "test_id" class="form-control" name="test_id" required>
                        <option value="">Select any one Test...</option>
                        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($test->id); ?>"><?php echo e($test->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="well well-sm">
                    <center><button type="submit" id="getlist" class="btn btn-primary">Get List</button></center>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script>
        $( document ).ready(function() {
            $( "#category_id" ).change(function() {
                var ajaxUrl = "<?php echo e(route('admin.getSubCategory')); ?>";
                $.ajax({
                    url: ajaxUrl,
                    type: 'GET',
                    data: {
                        category_id: $(this).val()
                    },
                    success:function(response) {
                        var $select = $('#sub_category_id');
                        $select.find('option').remove();
                        $select.append('<option value=' + '' + '>' + 'Select any one Sub Category...' + '</option>');
                        $.each(response,function(key, value) 
                        {
                            $select.append('<option value=' + key + '>' + value + '</option>');
                        });
                    }
                });
            });
            $( "#getlist" ).click(function(e) {
                e.preventDefault();
                if($("#category_id").val()=="" || $("#sub_category_id").val()=="" || $("#test_id").val()==""){
                    alert("Please fill all the fields");
                }
                else{
                    var queryString = "?category_id="+$("#category_id").val()+"&sub_category_id="+$("#sub_category_id").val()+"&test_id="+$("#test_id").val()
                    window.location = "<?php echo e(route('admin.questions.getQuestionLists')); ?>"+queryString;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>