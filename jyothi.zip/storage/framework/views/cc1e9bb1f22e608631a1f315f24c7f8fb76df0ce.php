<?php $__env->startSection('content'); ?>
    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <ul>
                <li><?php echo \Session::get('success'); ?></li>
            </ul>
        </div>
    <?php endif; ?>
    <div class="page-header">
        <h1>Users / Create </h1>
        <?php if(app('request')->input('role')=="student"): ?>
            <a href="<?php echo e(asset('excel/user.xlsx')); ?>">Sample User Excel</a>
            <form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 30px;" action="<?php echo e(route('admin.users.importExcel')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="file" name="import_file" />
                <?php if($errors->has("import_file")): ?>
                    <span class="help-block"><?php echo e($errors->first("import_file")); ?></span>
                <?php endif; ?>
                <br/>
                <button class="btn btn-primary">Import File</button>
            </form>
        <?php endif; ?>
    </div>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form class="form-horizontal" method="post" action="<?php echo e(route('admin.users.store')); ?>" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="form-group">
            <label class="control-label col-sm-3" for="fname">Name:</label>
            <div class="col-sm-6">
                <input type="text" class="form-control" id="name" name="name" placeholder="Name" required>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-3" for="email">Email:</label>
            <div class="col-sm-6">
                <input type="email" class="form-control" name="email" id="email" placeholder="Enter email" required>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-3" for="password">Password:</label>
            <div class="col-sm-6">
                <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-3" for="manager">Role:</label>
            <div class="col-sm-6">
                <input id="HR" type="radio" name="role" value="hr" required> <label for="HR">HR</label>
                <input id="Dept" type="radio" name="role" value="dept"> <label for="Dept">Department</label>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-3" for="confirmed   ">Active:</label>
            <div class="col-sm-6">
                <input id="active" type="radio" name="active" value="1" required> <label for="active">Yes</label>
                <input id="inactive" type="radio" name="active" value="0"> <label for="inactive">No</label>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-3" for="confirmed">Confirmed:</label>
            <div class="col-sm-6">
                <input id="yes" type="radio" name="confirmed" value="1" required> <label for="yes">Yes</label>
                <input id="no" type="radio" name="confirmed" value="0"> <label for="no">No</label>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-3" for="confirmed">Department:</label>
            <div class="col-sm-6">
                <select class="form-control" name="department_id" id="department_id">
                    <option value="">Select any one Department...</option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <br/>
        <br/>
        <div class="form-group"> 
            <div class="col-sm-12">
                <center><button type="submit" class="btn btn-success">Submit</button></center>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script>
        $( document ).ready(function() {
            $( "#college_id" ).change(function() {
                var ajaxUrl = "<?php echo e(route('admin.assigns.getGroup')); ?>";
                var $select = $('#group_id');
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>