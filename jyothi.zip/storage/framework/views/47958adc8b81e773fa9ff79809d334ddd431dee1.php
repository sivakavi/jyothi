

<?php $__env->startSection('title', __('views.admin.dashboard.title')); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-header clearfix"></div>

    

    <div class="row top_tiles margin-top-40">
                <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12" >
                    <div class="tile-stats">
                    <div class="icon"><i class="fa fa-users"></i></div>
                    <div class="count"><?php echo e($userCount); ?></div>
                    <h3 class="margin-top-20">No. of Users</h3>
                    </div>
                </div>
                <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="tile-stats">
                    <div class="icon"><i class="fa fa-cubes"></i></div>
                    <div class="count"><?php echo e($groupCount); ?></div>
                    <h3 class="margin-top-20">No. of Groups</h3>
                    </div>
                </div>
                <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a target="_blank" href="<?php echo e(route('staff.studentLists')); ?>?active=true">
                        <div class="tile-stats">
                        <div class="icon"><i class="fa fa-users"></i></div>
                        <div class="count"><?php echo e($activeUserCount); ?></div>
                        <h3 class="margin-top-20">No. of Active Users</h3>
                        </div>
                    </a>
                </div>
                <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <a target="_blank" href="<?php echo e(route('staff.studentLists')); ?>?inactive=true">
                        <div class="tile-stats">
                        <div class="icon"><i class="fa fa-users"></i></div>
                        <div class="count"><?php echo e($userCount-$activeUserCount); ?></div>
                        <h3 class="margin-top-20">No. of Inactive Users</h3>
                        </div>
                    </a>
                </div>
                
    </div>  
    <div class="divider"></div>
    <br/>
    <br/>
    <br/>
    <div class="row margin-top-50">
        <div class="form-group col-md-6 col-sm-12 col-xs-12">
            <label for="group_id">Filter Student by Group</label>
                <select id = "group_id" class="form-control" name="group_id" required>
                    <option value="">Select Any Group</option>
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <?php echo e(Html::script(mix('assets/admin/js/dashboard.js'))); ?>

    <script>
        $(function(){
            $('#group_id').change(function(e){
                e.preventDefault();
                if($(this).val()){
                    var url = "<?php echo e(route('staff.studentLists')); ?>";
                    window.open(
                    url+"?group_id="+$(this).val(),
                    '_blank' // <- This is what makes it open in a new window.
                    );
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <?php echo e(Html::style(mix('assets/admin/css/dashboard.css'))); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('staff.layouts.staff', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>