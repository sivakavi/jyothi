<div class="pull-right">
    &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. <?php echo e(__('views.backend.section.footer.copyright')); ?>

</div>
<div class="clearfix"></div>
