<?php $__env->startSection('title', __('views.admin.college.view.title')); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header clearfix"></div>
    <div class="row margin-top-30">
        <div class="col-md-8 col-sm-12 col-xs-12 center-margin">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><?php echo e($college->name); ?> <small>Details</small></h2>
                        <ul class="nav navbar-right">
                            <li class="cursor-pointer"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content margin-top-30">

                        <table class="table table-bordered">
                        <tbody>
                            <tr>
                            <th scope="row">ID</th>
                            <td><?php echo e($college->id); ?></td>
                            </tr>
                            <tr>
                            <th scope="row">NAME</th>
                            <td><?php echo e($college->name); ?></td>
                            </tr>
                            <tr>
                            <th scope="row">ADDRESS</th>
                            <td><?php echo e($college->address); ?></td>
                            </tr>
                            <tr>
                            <th scope="row">PH. NO</th>
                            <td><?php echo e($college->phno); ?></td>
                            </tr>
                            <tr>
                            <th scope="row">CONTACT PERSON</th>
                            <td><?php echo e($college->contact_person); ?></td>
                            </tr>
                            <tr>
                            <th scope="row">CONTACT PERSON PH. NO</th>
                            <td><?php echo e($college->contact_person_phno); ?></td>
                            </tr>
                            <tr>
                            <th scope="row">WEBSITE</th>
                            <td><?php echo e($college->website); ?></td>
                            </tr>
                        </tbody>
                        </table>
                    </div>
                </div>
        </div>
    </div>

    <a class="btn btn-link" href="<?php echo e(route('admin.colleges.index')); ?>"><i class="glyphicon glyphicon-backward"></i>  Back</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>