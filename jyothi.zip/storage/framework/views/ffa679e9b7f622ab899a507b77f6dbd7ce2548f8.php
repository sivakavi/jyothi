

<?php $__env->startSection('title', 'Lesson Detail'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header clearfix"></div>
   
<div class="row margin-top-30">
    <div class="col-md-8 col-sm-10 col-xs-12 center-margin">
    <div class="x_panel">
      <div class="x_title">
        <h2><?php echo e($subCategory['name']); ?></h2>
        <ul class="nav navbar-right">
        <li class="cursor-pointer"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
        </li>
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <div class="margin-top-40" role="tabpanel" data-example-id="togglable-tabs">
          <ul id="myTab" class="nav nav-tabs bar_tabs right" role="tablist" style="background: inherit !important;">
            <li role="presentation" class="active">
                <a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">
                &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; Lessons &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </a>
            </li>
            <li role="presentation" class="">
                <a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Tests &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </a>
            </li>
          </ul>
          <div id="myTabContent" class="tab-content">
            <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                <?php $__currentLoopData = $subCategoryFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategoryFileId => $subCategoryFileName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('student.view.pdf', $subCategoryFileId)); ?>"><button type="button" class="btn btn-success margin-top-20"><?php echo e($subCategoryFileName); ?></button></a>
                <br/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                <?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testId => $testName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('student.test', $testId, $subCategory['id'])); ?>?subCatId=<?php echo e($subCategory['id']); ?>"><button type="button" class="btn btn-warning margin-top-20"><?php echo e($testName); ?></button></a>
                <br/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <?php echo e(Html::script(mix('assets/admin/js/dashboard.js'))); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <?php echo e(Html::style(mix('assets/admin/css/dashboard.css'))); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.student', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>