<?php $__env->startSection('content'); ?>
    <h1>SubCategories / Show #<?php echo e($sub_category->id); ?></h1>
    <form action="<?php echo e(route('admin.sub_categories.destroy', $sub_category->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };">
        <input type="hidden" name="_method" value="DELETE">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="btn-group pull-right" role="group" aria-label="...">
            <a class="btn btn-warning btn-group" role="group" href="<?php echo e(route('admin.sub_categories.edit', $sub_category->id)); ?>"><i class="glyphicon glyphicon-edit"></i> Edit</a>
            <button type="submit" class="btn btn-danger">Delete <i class="glyphicon glyphicon-trash"></i></button>
        </div>
    </form>
    <div class="row">
        <div class="col-md-12">
            <form action="#">
                <div class="form-group">
                     <label for="name">NAME</label>
                     <p class="form-control-static"><?php echo e($sub_category->name); ?></p>
                </div>
                    <div class="form-group">
                     <label for="file">FILE</label>
                     <p class="form-control-static"><a href="<?php echo e(asset('uploads/'.$sub_category->file)); ?>"><?php echo e($sub_category->file); ?></a></p>
                </div>
                    <div class="form-group">
                     <label for="category_id">CATEGORY</label>
                     <p class="form-control-static"><?php echo e($sub_category->category()->first()->name); ?></p>
                </div>
            </form>

            <a class="btn btn-link" href="<?php echo e(route('admin.sub_categories.index')); ?>"><i class="glyphicon glyphicon-backward"></i>  Back</a>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>