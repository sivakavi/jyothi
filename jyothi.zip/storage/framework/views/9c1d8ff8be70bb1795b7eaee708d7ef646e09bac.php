<?php $__env->startSection('title', __('views.admin.group.edit.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header clearfix">
        
    </div>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row margin-top-30">
        <div class="col-md-8 center-margin">
            <form action="<?php echo e(route('admin.groups.update', $group->id)); ?>" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Group Update Form</h2>
                                    <ul class="nav navbar-right">
                                    <li class="cursor-pointer"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content margin-top-40">
                                    <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                                        <label for="name-field">Name</label>
                                        <input type="text" id="name-field" name="name" class="form-control" value="<?php echo e(is_null(old("name")) ? $group->name : old("name")); ?>"/>
                                        <?php if($errors->has("name")): ?>
                                            <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php if($errors->has('college_id')): ?> has-error <?php endif; ?>">
                                        <label for="college_id">College</label>
                                            <select class="form-control" name="college_id">
                                                <option value="">Select any one College...</option>
                                                <?php $__currentLoopData = $colleges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $college): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($college->id); ?>" <?php if($college->id == $group->college()->first()->id): ?> selected <?php endif; ?>><?php echo e($college->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php if($errors->has("college_id")): ?>
                                            <span class="help-block"><?php echo e($errors->first("college_id")); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php if($errors->has('expiry')): ?> has-error <?php endif; ?>">
                                        <label for="expiry">Expiry Date</label>
                                        <input type="date" id="expiry" name="expiry" class="form-control" value="<?php echo e(is_null(old("expiry")) ? $group->expiry : old("expiry")); ?>"/>
                                        <?php if($errors->has("expiry")): ?>
                                            <span class="help-block"><?php echo e($errors->first("expiry")); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="well well-sm margin-top-50">
                                        <button type="submit" class="btn btn-primary btn-round btn-sm">Update Group</button>
                                        <a class="btn btn-link pull-right" href="<?php echo e(route('admin.groups.index')); ?>"><i class="glyphicon glyphicon-backward"></i>  Back</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
  <script>
    $('.date-picker').datepicker({
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>