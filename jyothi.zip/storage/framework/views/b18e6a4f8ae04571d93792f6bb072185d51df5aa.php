
<?php $__env->startSection('content'); ?>
    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <ul>
                <li><?php echo \Session::get('success'); ?></li>
            </ul>
        </div>
    <?php endif; ?>
    <div class="page-header">
        <h1>Questions / Create </h1>
    </div>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-7 center-margin">

        <a href="<?php echo e(asset('excel/questions.xlsx')); ?>" class="btn btn-success">Sample Question Excel</a>
        <form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 10px;" action="<?php echo e(route('admin.question.importExcel')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="file" name="import_file" />
            <?php if($errors->has("import_file")): ?>
                <span class="help-block"><?php echo e($errors->first("import_file")); ?></span>
            <?php endif; ?>
            <br/>
            <br/>
            <button class="btn btn-primary">Import File</button>
        </form>
        <br/>
        <br/>

            <form action="<?php echo e(route('admin.questions.store')); ?>" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                
                <div class="form-group <?php if($errors->has('category_id')): ?> has-error <?php endif; ?>">
                    <label for="category_id">Category</label>
                    <select id = 
                    "category_id" class="form-control" name="category_id">
                        <option value="">Select any one Category...</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has("category_id")): ?>
                    <span class="help-block"><?php echo e($errors->first("category_id")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('sub_category_id')): ?> has-error <?php endif; ?>">
                    <label for="sub_category_id">Sub_Category</label>
                    <select id = "sub_category_id" class="form-control" name="sub_category_id" required>
                        <option value="">Select any one Sub Category...</option>
                    </select>
                    <?php if($errors->has("sub_category_id")): ?>
                    <span class="help-block"><?php echo e($errors->first("sub_category_id")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('test_id')): ?> has-error <?php endif; ?>">
                    <label for="test_id">Test</label>
                    <select id = 
                    "test_id" class="form-control" name="test_id">
                        <option value="">Select any one Test...</option>
                        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($test->id); ?>"><?php echo e($test->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has("test_id")): ?>
                    <span class="help-block"><?php echo e($errors->first("test_id")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('question')): ?> has-error <?php endif; ?>">
                    <label for="question">Question</label>
                    <textarea id="question" name="question" class="form-control"></textarea>
                    <?php if($errors->has("question")): ?>
                        <span class="help-block"><?php echo e($errors->first("question")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('image')): ?> has-error <?php endif; ?>">
                    <label class="control-label col-sm-3" for="image">Image:</label>
                    <input type="file" class="form-control" name="image" id="image">
                    <?php if($errors->has("image")): ?>
                        <span class="help-block"><?php echo e($errors->first("image")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('answer1')): ?> has-error <?php endif; ?>">
                    <label for="answer1">Answer 1</label>
                    <input type="text" id="answer1" name="answer1" class="form-control" value="<?php echo e(old("answer1")); ?>"/>
                    <?php if($errors->has("answer1")): ?>
                        <span class="help-block"><?php echo e($errors->first("answer1")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('answer2')): ?> has-error <?php endif; ?>">
                    <label for="answer2">Answer 2</label>
                    <input type="text" id="answer2" name="answer2" class="form-control" value="<?php echo e(old("answer2")); ?>"/>
                    <?php if($errors->has("answer2")): ?>
                        <span class="help-block"><?php echo e($errors->first("answer2")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('answer3')): ?> has-error <?php endif; ?>">
                    <label for="answer3">Answer 3</label>
                    <input type="text" id="answer3" name="answer3" class="form-control" value="<?php echo e(old("answer3")); ?>"/>
                    <?php if($errors->has("answer3")): ?>
                        <span class="help-block"><?php echo e($errors->first("answer3")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('answer4')): ?> has-error <?php endif; ?>">
                    <label for="answer4">Answer 4</label>
                    <input type="text" id="answer4" name="answer4" class="form-control" value="<?php echo e(old("answer4")); ?>"/>
                    <?php if($errors->has("answer4")): ?>
                        <span class="help-block"><?php echo e($errors->first("answer4")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('correct_answer')): ?> has-error <?php endif; ?>">
                    <label for="correct_answer">Correct Answer</label>
                    <select id = 
                    "correct_answer" class="form-control" name="correct_answer">
                        <option value="1">Answer 1</option>
                        <option value="2">Answer 2</option>
                        <option value="3">Answer 3</option>
                        <option value="4">Answer 4</option>
                    </select>
                    <?php if($errors->has("correct_answer")): ?>
                    <span class="help-block"><?php echo e($errors->first("correct_answer")); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?php if($errors->has('description')): ?> has-error <?php endif; ?>">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" class="form-control"></textarea>
                    <?php if($errors->has("description")): ?>
                        <span class="help-block"><?php echo e($errors->first("description")); ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="well well-sm">
                    <button type="submit" class="btn btn-primary">Create</button>
                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.questions.create')); ?>"><i class="glyphicon glyphicon-backward"></i> Back</a>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <script>
        $( document ).ready(function() {
            $( "#category_id" ).change(function() {
                var ajaxUrl = "<?php echo e(route('admin.getSubCategory')); ?>";
                $.ajax({
                    url: ajaxUrl,
                    type: 'GET',
                    data: {
                        category_id: $(this).val()
                    },
                    success:function(response) {
                        var $select = $('#sub_category_id');
                        $select.find('option').remove();
                        $select.append('<option value=' + '' + '>' + 'Select any one Sub Category...' + '</option>');
                        $.each(response,function(key, value) 
                        {
                            $select.append('<option value=' + key + '>' + value + '</option>');
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>