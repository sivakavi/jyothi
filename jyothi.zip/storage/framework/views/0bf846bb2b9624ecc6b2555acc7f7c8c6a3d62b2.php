

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1><i class="glyphicon glyphicon-edit"></i> SubCategories / Edit #<?php echo e($sub_category->id); ?></h1>
        
    </div>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <br/>
    <a class="btn btn-success pull-right" href="<?php echo e(route('admin.sub_categories_file.index',['sub_category_id' => $sub_category->id])); ?>"><i class="glyphicon glyphicon-plus"></i> File Upload</a>
<br/>
    <div class="row">
        <div class="col-md-6 center-margin">

            <form action="<?php echo e(route('admin.sub_categories.update', $sub_category->id)); ?>" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                       <label for="name-field">Name</label>
                    <input type="text" id="name-field" name="name" class="form-control" value="<?php echo e(is_null(old("name")) ? $sub_category->name : old("name")); ?>"/>
                       <?php if($errors->has("name")): ?>
                        <span class="help-block"><?php echo e($errors->first("name")); ?></span>
                       <?php endif; ?>
                    </div>
                    
                    <div class="form-group <?php if($errors->has('category_id')): ?> has-error <?php endif; ?>">
                       <label for="category_id-field">Category</label>
                        <select class="form-control" name="category_id">
                            <option value="">Select any one Category...</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php if($category->id == $sub_category->category()->first()->id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                       <?php if($errors->has("category_id")): ?>
                        <span class="help-block"><?php echo e($errors->first("category_id")); ?></span>
                       <?php endif; ?>
                    </div>
                <div class="well well-sm">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <a class="btn btn-link pull-right" href="<?php echo e(route('admin.sub_categories.index')); ?>"><i class="glyphicon glyphicon-backward"></i>  Back</a>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
  <script>
    $('.date-picker').datepicker({
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>