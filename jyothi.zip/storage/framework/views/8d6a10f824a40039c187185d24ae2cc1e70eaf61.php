

<?php $__env->startSection('title', __('views.admin.dashboard.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header clearfix"></div>
    <div class="margin-top-30">
        <div class="row top_tiles">
                <div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="tile-stats">
                    <div class="icon"><i class="fa fa-institution"></i></div>
                    <div class="count"><?php echo e($college); ?></div>
                    <h3>Colleges</h3>
                    <p>No. of Colleges.</p>
                    </div>
                </div>
                <div class="animated flipInY col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="tile-stats">
                    <div class="icon"><i class="fa fa-cubes"></i></div>
                    <div class="count"><?php echo e($category); ?></div>
                    <h3>Categories</h3>
                    <p>No. of Categories.</p>
                    </div>
                </div>
        </div>
        <div class="row margin-top-30">
            <div class="col-md-10 col-sm-12 col-xs-12 center-margin">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Group Expiry Notifications</h2>
                    <ul class="nav navbar-right">
                      <li class="cursor-pointer"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <?php if(count($groups)): ?>
                      <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="media event">
                          <a class="pull-left date article-date-width">
                            <p class="month"><?php echo e(date('M', strtotime($group->expiry))); ?></p>
                            <p class="day"><?php echo e(date('d', strtotime($group->expiry))); ?></p>
                            <p class="month"><?php echo e(date('Y', strtotime($group->expiry))); ?></p>
                          </a>
                          <div class="media-body">
                            <a class="title" href="<?php echo e(route('admin.colleges.show', $group->college()->first()->id)); ?>"><?php echo e($group->college()->first()->name); ?></a><br>
                            <a class="title" href="<?php echo e(route('admin.groups.show', $group->id)); ?>"><?php echo e($group->name); ?></a>
                          </div>
                        </article>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                     <p>No expiry found</p>
                    <?php endif; ?>
                  </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <?php echo e(Html::script(mix('assets/admin/js/dashboard.js'))); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <?php echo e(Html::style(mix('assets/admin/css/dashboard.css'))); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>