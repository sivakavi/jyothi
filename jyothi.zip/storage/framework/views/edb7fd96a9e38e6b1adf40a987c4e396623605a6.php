

<?php $__env->startSection('title', 'Lessons List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header clearfix"></div>
    
    <div class="row margin-top-40">

    <?php if(count($subCategories)): ?>
        <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-xs-12 widget widget_tally_box max-width-none">
            <div class="x_panel ui-ribbon-container">
                <!-- <div class="ui-ribbon-wrapper">
                    <div class="ui-ribbon">
                    30% Off
                    </div>
                </div> -->
                <div class="x_title">
                    <h2 class="white-space"><?php echo e($subCategory['name']); ?></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="row">
                        <div class="col-md-6">
                        <div style="margin-bottom: 17px">
                                <div class="c100 p<?php echo e($subCategory['progress']); ?>">
                                <span><?php echo e($subCategory['progress']); ?>%</span>
                                <div class="slice">
                                    <div class="bar"></div>
                                    <div class="fill"></div>
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                        <p><?php echo e($subCategory['category_name']); ?></p>
                        <div class="divider"></div>
                        <center>
                            <a href="<?php echo e(route('student.sub.category', $subCategory['id'])); ?>">
                                <button type="button" class="btn btn-round btn-success">Detail View</button>
                            </a>
                        </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No Sub Category found</p>
    <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <?php echo e(Html::script(mix('assets/admin/js/dashboard.js'))); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    ##parent-placeholder-bf62280f159b1468fff0c96540f3989d41279669##
    <?php echo e(Html::style(mix('assets/admin/css/dashboard.css'))); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.student', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>