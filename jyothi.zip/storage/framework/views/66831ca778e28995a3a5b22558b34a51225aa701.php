


<?php $__env->startSection('title', 'Change Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header clearfix"></div>
<div class="margin-top-50">
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php if( Session::has( 'success' )): ?>
        <div class="alert alert-success alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Success!</strong> <?php echo e(Session::get( 'success' )); ?>

        </div>
    <?php endif; ?>
    <form id="form-change-password" role="form" method="POST" action="<?php echo e(route('users.change-password')); ?>" novalidate class="form-horizontal">
        <div class="col-md-9">             
            <label for="current-password" class="col-sm-4 control-label">Current Password</label>
            <div class="col-sm-8">
            <div class="form-group">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                <input type="password" class="form-control" id="current-password" name="current-password" placeholder="Password">
            </div>
            </div>
            <label for="password" class="col-sm-4 control-label">New Password</label>
            <div class="col-sm-8">
            <div class="form-group">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
            </div>
            </div>
            <label for="password_confirmation" class="col-sm-4 control-label">Re-enter Password</label>
            <div class="col-sm-8">
            <div class="form-group">
                <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Re-enter Password">
            </div>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-5 col-sm-6">
            <button type="submit" class="btn btn-danger">Submit</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('staff.layouts.staff', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>